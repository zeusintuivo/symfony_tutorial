Joyful Development with Symfony
===============================

Well hi there! This repository holds the code and script
for the Symfony course on KnpUniversity.

And as always, thanks so much for your support and letting us do what
we love!

<3 Your friends at KnpUniversity
